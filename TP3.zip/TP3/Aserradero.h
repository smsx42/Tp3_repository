#ifndef ASERRADERO_H_INCLUDED
#define ASERRADERO_H_INCLUDED
#include "Edificio.h"

class Aserradero: public Edificio{


};

#endif // ASERRADERO_H_INCLUDED