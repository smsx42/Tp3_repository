#ifndef FABRICA_H_INCLUDED
#define FABRICA_H_INCLUDED
#include "Edificio.h"

class Fabrica: public Edificio{



};

#endif // EDIFICIO_H_INCLUDED