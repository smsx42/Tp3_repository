#ifndef PLANTA_ELECTRICA_H_INCLUDED
#define PLANTA_ELECTRICA_H_INCLUDED
#include "Edificio.h"

class Planta_electrica: public Edificio{



};

#endif // PLANTA_ELECTRICA_H_INCLUDED