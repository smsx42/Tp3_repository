#include "Datos.h"
#include "constantes.h"
#include <iostream>

using namespace std;

void Datos::cargar_inventario(){

    ifstream archivo_materiales(PATH_MATERIALES);

    if(!archivo_materiales.fail()){

        Inventario inventario_1;
        Inventario inventario_2;
        string nombre_material;
        int cantidad_material_1;
        int cantidad_material_2;

        while(archivo_materiales >> nombre_material){

            archivo_materiales >> cantidad_material_1;
            archivo_materiales >> cantidad_material_2;

            inventario_1.agregar_material(nombre_material, cantidad_material_1);
            inventario_2.agregar_material(nombre_material, cantidad_material_2);
        }

        jugador_1.obtener_inventario(inventario_1);
        jugador_2.obtener_inventario(inventario_2);
    }
    else{
        cout << "ERROR AL LEER EL ARCHIVO " << PATH_MATERIALES << "." << endl;
    }

    archivo_materiales.close();


}

void Datos::cargar_edificios(){

    ifstream archivo_edificios(PATH_EDIFICIOS);

    if(!archivo_edificios.fail()){

        Diccionario<Edificio> *dic_edificios_1 = new Diccionario<Edificio>();
        Edificio edificio_1;
        Edificio *aux;

        string nombre_edificio;
        int cant_piedra;
        int cant_madera;
        int cant_metal;
        int cant_max_edificos;

        while(archivo_edificios >> nombre_edificio){
            
            archivo_edificios >> cant_piedra;
            archivo_edificios >> cant_madera;
            archivo_edificios >> cant_metal;

            archivo_edificios >> cant_max_edificos;

            edificio_1.obtener_edificio(nombre_edificio, cant_piedra, cant_madera, cant_metal, cant_max_edificos);
            aux = &edificio_1;
            dic_edificios_1->insertar(nombre_edificio, aux);
        }


        jugador_1.obtener_edificios(dic_edificios_1);

    }
    else{
        cout << "ERROR AL LEER EL ARCHIVO " << PATH_EDIFICIOS << endl;
    }

    archivo_edificios.close();
}

Jugador Datos::devovler_jugador_1(){

    return jugador_1;
}

Jugador Datos::devovler_jugador_2(){

    return jugador_2;
}