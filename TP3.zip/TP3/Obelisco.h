#ifndef OBELISCO_H_INCLUDED
#define OBELISCO_H_INCLUDED
#include "Edificio.h"

class Obelisco: public Edificio{


};

#endif // OBELISCO_H_INCLUDED