#ifndef MINA_ORO_H_INCLUDED
#define MINA_ORO_H_INCLUDED
#include "Edificio.h"

class Mina: public Edificio{



};

#endif // MINA_ORO_H_INCLUDED