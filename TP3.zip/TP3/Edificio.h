#ifndef EDIFICIO_H_INCLUDED
#define EDIFICIO_H_INCLUDED
#include <string>

const int CANT_MAX_MATERIALES = 3;

class Edificio{

    protected:

    std::string nombre_edificio;
    int cant_piedra;
    int cant_madera;
    int cant_metal;
    int cant_maxima_edificios;
    char representacion;

    public:

    // PRE: -
    // POST: Inicializa el edificio.
    Edificio();

    // PRE: -
    // POST: Obtiene un edificio.
    void obtener_edificio(std::string nombre_edificio, int cant_piedra, int madera_, int cant_metal, int cant_maxima_edificios);

    // PRE: -
    // POST: Devuelve el nombhre del edificio.
    std::string devolver_nombre_edificio();

    // PRE: -
    // POST: Devuelve la cantidad maxima de edificios.
    int devolver_cant_maxima_edificios();

};

#endif // EDIFICIO_H_INCLUDED