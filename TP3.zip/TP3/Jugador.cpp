#include "Jugador.h"

Jugador::Jugador(){

    crear_diccionario();

}

void Jugador::obtener_inventario(Inventario invnetario){
    
    limpiar_inventario();
    this-> inventario = invnetario;
}

Inventario Jugador::devolver_inventario(){

    return inventario;
}

void Jugador::limpiar_inventario(){

    delete[] inventario.devolver_materiales();

}

void Jugador::crear_diccionario(){

    edificios = new Diccionario<Edificio>(); 
}

void Jugador::obtener_edificios(Diccionario<Edificio>* edificios){
    
    this-> edificios = edificios;
}

Diccionario<Edificio>* Jugador::devolver_edificios(){

    return edificios;
}

void Jugador::limpiar_edificios(){

    edificios->eliminar_memoria();
}
