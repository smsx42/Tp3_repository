#ifndef JUGADOR_H_INCLUDED
#define JUGADOR_H_INCLUDED
#include "Inventario.h"
#include "Edificio.h"
#include "Diccionario.h"

class Jugador{

    private:

    Inventario inventario;
    Diccionario<Edificio>* edificios;

    public:
    
    // PRE: -
    // POST: Inicializa el jugador.
    Jugador();

    // PRE: EL invnetario esta bien cargado.
    // POST: Se obtiene el inventario del jugador.
    void obtener_inventario(Inventario inventario);
    
    // PRE: -
    // POST: Devuelve el inventario del jugador.
    Inventario devolver_inventario();
    
    // PRE: -
    // POST: Limpia la memoria dinamica de los materiales dependindo del inventario del juagador.
    void limpiar_inventario();

    // PRE: -
    // POST: Crea el diccionario.
    void crear_diccionario();
    
    // PRE: El diccionario es valido.
    // POST: Se obtiene le diccionario de edificios.
    void obtener_edificios(Diccionario<Edificio> *edificios);

    // PRE: -
    // POST: Devuelve el diccionario de edificios.
    Diccionario<Edificio>* devolver_edificios();

    // PRE: -
    // POST: Limpia la memoria dincamica de los edificios.
    void limpiar_edificios();
    





};

#endif // JUGADOR_H_INCLUDED